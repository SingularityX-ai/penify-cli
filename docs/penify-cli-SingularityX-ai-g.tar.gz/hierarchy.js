var hierarchy =
[
    [ "api_client.APIClient", "classapi__client_1_1APIClient.html", null ],
    [ "commit_analyzer.CommitDocGenHook", "classcommit__analyzer_1_1CommitDocGenHook.html", null ],
    [ "Exception", "classException.html", [
      [ "utils.GitRepoNotFoundError", "classutils_1_1GitRepoNotFoundError.html", null ]
    ] ],
    [ "file_analyzer.FileAnalyzerGenHook", "classfile__analyzer_1_1FileAnalyzerGenHook.html", null ],
    [ "folder_analyzer.FolderAnalyzerGenHook", "classfolder__analyzer_1_1FolderAnalyzerGenHook.html", null ],
    [ "git_analyzer.GitDocGenHook", "classgit__analyzer_1_1GitDocGenHook.html", null ]
];