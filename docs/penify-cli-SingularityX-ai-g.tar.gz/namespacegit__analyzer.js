var namespacegit__analyzer =
[
    [ "GitDocGenHook", "classgit__analyzer_1_1GitDocGenHook.html", "classgit__analyzer_1_1GitDocGenHook" ]
];