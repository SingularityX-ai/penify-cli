var namespacecommit__analyzer =
[
    [ "CommitDocGenHook", "classcommit__analyzer_1_1CommitDocGenHook.html", "classcommit__analyzer_1_1CommitDocGenHook" ]
];