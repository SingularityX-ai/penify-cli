var git__analyzer_8py =
[
    [ "git_analyzer.GitDocGenHook", "classgit__analyzer_1_1GitDocGenHook.html", "classgit__analyzer_1_1GitDocGenHook" ]
];