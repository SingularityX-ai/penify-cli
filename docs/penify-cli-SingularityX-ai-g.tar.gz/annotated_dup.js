var annotated_dup =
[
    [ "api_client", "namespaceapi__client.html", [
      [ "APIClient", "classapi__client_1_1APIClient.html", "classapi__client_1_1APIClient" ]
    ] ],
    [ "commit_analyzer", "namespacecommit__analyzer.html", [
      [ "CommitDocGenHook", "classcommit__analyzer_1_1CommitDocGenHook.html", "classcommit__analyzer_1_1CommitDocGenHook" ]
    ] ],
    [ "file_analyzer", "namespacefile__analyzer.html", [
      [ "FileAnalyzerGenHook", "classfile__analyzer_1_1FileAnalyzerGenHook.html", "classfile__analyzer_1_1FileAnalyzerGenHook" ]
    ] ],
    [ "folder_analyzer", "namespacefolder__analyzer.html", [
      [ "FolderAnalyzerGenHook", "classfolder__analyzer_1_1FolderAnalyzerGenHook.html", "classfolder__analyzer_1_1FolderAnalyzerGenHook" ]
    ] ],
    [ "git_analyzer", "namespacegit__analyzer.html", [
      [ "GitDocGenHook", "classgit__analyzer_1_1GitDocGenHook.html", "classgit__analyzer_1_1GitDocGenHook" ]
    ] ],
    [ "utils", "namespaceutils.html", [
      [ "GitRepoNotFoundError", "classutils_1_1GitRepoNotFoundError.html", null ]
    ] ],
    [ "Exception", "classException.html", null ]
];