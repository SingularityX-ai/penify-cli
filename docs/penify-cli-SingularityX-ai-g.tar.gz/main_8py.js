var main_8py =
[
    [ "commit_code", "main_8py.html#a5754b28669981f6ed6b3d5c62aef259f", null ],
    [ "generate_doc", "main_8py.html#a6568610bf9f969e7129f30417d1ec212", null ],
    [ "get_token", "main_8py.html#af6cd733a1e7a34da9a58510285b63bc7", null ],
    [ "install_git_hook", "main_8py.html#a3e494c4723342a16da721b682c2ad95d", null ],
    [ "login", "main_8py.html#a325d966924c7c2622fcc50c3626bc8ed", null ],
    [ "main", "main_8py.html#af613cea4cba4fb7de8e40896b3368945", null ],
    [ "save_credentials", "main_8py.html#a8cf2a5becaa2433301d49eed685f49a6", null ],
    [ "uninstall_git_hook", "main_8py.html#a1dd4c4eb546efac3d25779ebb7e23d8c", null ],
    [ "api_url", "main_8py.html#a5cda5552714bcfd2511cb8e0a5c8a785", null ],
    [ "dashboard_url", "main_8py.html#a1fb31e86e65fca9941931147cf5e18d8", null ],
    [ "HOOK_FILENAME", "main_8py.html#ac715999c10e838574d30a343243bc54a", null ],
    [ "HOOK_TEMPLATE", "main_8py.html#ac6a9c57b7ff6db3365956d489a2ddcd7", null ]
];