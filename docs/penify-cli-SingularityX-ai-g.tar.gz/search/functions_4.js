var searchData=
[
  ['install_5fgit_5fhook_0',['install_git_hook',['../namespacemain.html#a3e494c4723342a16da721b682c2ad95d',1,'main']]]
];
