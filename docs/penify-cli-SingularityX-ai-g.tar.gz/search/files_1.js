var searchData=
[
  ['commit_5fanalyzer_2epy_0',['commit_analyzer.py',['../commit__analyzer_8py.html',1,'']]]
];
