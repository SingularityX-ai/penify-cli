var searchData=
[
  ['install_5fgit_5fhook_0',['install_git_hook',['../namespacemain.html#a3e494c4723342a16da721b682c2ad95d',1,'main']]],
  ['install_5frequires_1',['install_requires',['../namespacesetup.html#abead4f26b530856f858f0d44c7cf2588',1,'setup']]]
];
