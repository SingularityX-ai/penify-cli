var searchData=
[
  ['git_5fanalyzer_2epy_0',['git_analyzer.py',['../git__analyzer_8py.html',1,'']]]
];
