var searchData=
[
  ['git_5fanalyzer_0',['git_analyzer',['../namespacegit__analyzer.html',1,'']]]
];
