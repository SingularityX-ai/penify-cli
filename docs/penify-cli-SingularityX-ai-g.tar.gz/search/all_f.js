var searchData=
[
  ['save_5fcredentials_0',['save_credentials',['../namespacemain.html#a8cf2a5becaa2433301d49eed685f49a6',1,'main']]],
  ['send_5ffile_5ffor_5fdocstring_5fgeneration_1',['send_file_for_docstring_generation',['../classapi__client_1_1APIClient.html#a9d60b6b945998acba45dc1c944dcbb83',1,'api_client::APIClient']]],
  ['setup_2',['setup',['../namespacesetup.html',1,'']]],
  ['setup_2epy_3',['setup.py',['../setup_8py.html',1,'']]],
  ['supported_5ffile_5ftypes_4',['supported_file_types',['../classcommit__analyzer_1_1CommitDocGenHook.html#a8814e69d03a2ca9fe897acc8ae02535c',1,'commit_analyzer.CommitDocGenHook.supported_file_types()'],['../classfile__analyzer_1_1FileAnalyzerGenHook.html#a60ac367a22436676404bb4566fc588f6',1,'file_analyzer.FileAnalyzerGenHook.supported_file_types()'],['../classgit__analyzer_1_1GitDocGenHook.html#a41712029c362fca7f765017e1ef83334',1,'git_analyzer.GitDocGenHook.supported_file_types()']]]
];
