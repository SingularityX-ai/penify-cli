var searchData=
[
  ['api_5fclient_0',['api_client',['../namespaceapi__client.html',1,'']]]
];
