var searchData=
[
  ['repo_0',['repo',['../classcommit__analyzer_1_1CommitDocGenHook.html#ad5297f68e5d4df58ffcc7c2c0556e1e6',1,'commit_analyzer.CommitDocGenHook.repo()'],['../classgit__analyzer_1_1GitDocGenHook.html#a998e21d2ecb776f7b8702a29f5816061',1,'git_analyzer.GitDocGenHook.repo()']]],
  ['repo_5fdetails_1',['repo_details',['../classcommit__analyzer_1_1CommitDocGenHook.html#adaa6d37ea3f0f2096220099f132c5f53',1,'commit_analyzer.CommitDocGenHook.repo_details()'],['../classgit__analyzer_1_1GitDocGenHook.html#a72b9a0308edf639335073b065b2f294c',1,'git_analyzer.GitDocGenHook.repo_details()']]],
  ['repo_5fpath_2',['repo_path',['../classcommit__analyzer_1_1CommitDocGenHook.html#a9c0f97f01a967edd3c8a5492cb9e8237',1,'commit_analyzer.CommitDocGenHook.repo_path()'],['../classgit__analyzer_1_1GitDocGenHook.html#ae5f012a7a552d15f848b6e1903e4fd97',1,'git_analyzer.GitDocGenHook.repo_path()']]]
];
