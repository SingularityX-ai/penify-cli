var searchData=
[
  ['commitdocgenhook_0',['CommitDocGenHook',['../classcommit__analyzer_1_1CommitDocGenHook.html',1,'commit_analyzer']]]
];
