var searchData=
[
  ['uninstall_5fgit_5fhook_0',['uninstall_git_hook',['../namespacemain.html#a1dd4c4eb546efac3d25779ebb7e23d8c',1,'main']]]
];
