var searchData=
[
  ['install_5frequires_0',['install_requires',['../namespacesetup.html#abead4f26b530856f858f0d44c7cf2588',1,'setup']]]
];
