var searchData=
[
  ['entry_5fpoints_0',['entry_points',['../namespacesetup.html#ada7058afc98897f073d3f3b8b9157059',1,'setup']]]
];
