var searchData=
[
  ['gitdocgenhook_0',['GitDocGenHook',['../classgit__analyzer_1_1GitDocGenHook.html',1,'git_analyzer']]],
  ['gitreponotfounderror_1',['GitRepoNotFoundError',['../classutils_1_1GitRepoNotFoundError.html',1,'utils']]]
];
