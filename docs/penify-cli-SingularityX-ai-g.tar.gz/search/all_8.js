var searchData=
[
  ['hook_5ffilename_0',['HOOK_FILENAME',['../namespacemain.html#ac715999c10e838574d30a343243bc54a',1,'main']]],
  ['hook_5ftemplate_1',['HOOK_TEMPLATE',['../namespacemain.html#ac6a9c57b7ff6db3365956d489a2ddcd7',1,'main']]]
];
