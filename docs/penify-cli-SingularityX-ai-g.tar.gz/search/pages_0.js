var searchData=
[
  ['penify_20cli_0',['Penify CLI',['../md__tmp_github_repos_arch_doc_gen_SingularityX_ai_penify_cli_README.html',1,'']]]
];
