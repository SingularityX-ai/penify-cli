var searchData=
[
  ['find_5fgit_5fparent_0',['find_git_parent',['../namespaceutils.html#ad9e472f4893cc6ba4b57b97fd5d8d7c8',1,'utils']]]
];
