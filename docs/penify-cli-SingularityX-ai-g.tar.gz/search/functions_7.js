var searchData=
[
  ['process_5ffile_0',['process_file',['../classfile__analyzer_1_1FileAnalyzerGenHook.html#a18a6bae101fd740b7e8ff588c2338263',1,'file_analyzer.FileAnalyzerGenHook.process_file()'],['../classgit__analyzer_1_1GitDocGenHook.html#a4524f438ea3fc33abebd667f0d2e28a0',1,'git_analyzer.GitDocGenHook.process_file()']]]
];
