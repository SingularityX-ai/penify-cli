var searchData=
[
  ['packages_0',['packages',['../namespacesetup.html#aff2375a361fd5865c77bd9aa093be747',1,'setup']]],
  ['penify_20cli_1',['Penify CLI',['../md__tmp_github_repos_arch_doc_gen_SingularityX_ai_penify_cli_README.html',1,'']]],
  ['process_5ffile_2',['process_file',['../classfile__analyzer_1_1FileAnalyzerGenHook.html#a18a6bae101fd740b7e8ff588c2338263',1,'file_analyzer.FileAnalyzerGenHook.process_file()'],['../classgit__analyzer_1_1GitDocGenHook.html#a4524f438ea3fc33abebd667f0d2e28a0',1,'git_analyzer.GitDocGenHook.process_file()']]],
  ['python_5frequires_3',['python_requires',['../namespacesetup.html#aa7ca7bc9391b217e81efeb03689d8dbf',1,'setup']]]
];
