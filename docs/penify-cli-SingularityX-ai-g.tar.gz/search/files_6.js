var searchData=
[
  ['setup_2epy_0',['setup.py',['../setup_8py.html',1,'']]]
];
