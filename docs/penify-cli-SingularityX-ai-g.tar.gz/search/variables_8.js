var searchData=
[
  ['long_5fdescription_0',['long_description',['../namespacesetup.html#a4cda9dbfb952875376a0749fe08a5bde',1,'setup']]],
  ['long_5fdescription_5fcontent_5ftype_1',['long_description_content_type',['../namespacesetup.html#a3796ea10c998699d07d391414ff5d720',1,'setup']]]
];
