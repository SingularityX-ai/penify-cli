var searchData=
[
  ['save_5fcredentials_0',['save_credentials',['../namespacemain.html#a8cf2a5becaa2433301d49eed685f49a6',1,'main']]],
  ['send_5ffile_5ffor_5fdocstring_5fgeneration_1',['send_file_for_docstring_generation',['../classapi__client_1_1APIClient.html#a9d60b6b945998acba45dc1c944dcbb83',1,'api_client::APIClient']]]
];
