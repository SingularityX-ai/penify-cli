var utils_8py =
[
    [ "utils.GitRepoNotFoundError", "classutils_1_1GitRepoNotFoundError.html", null ],
    [ "find_git_parent", "utils_8py.html#ad9e472f4893cc6ba4b57b97fd5d8d7c8", null ]
];