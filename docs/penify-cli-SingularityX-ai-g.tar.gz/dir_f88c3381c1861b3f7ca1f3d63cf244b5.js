var dir_f88c3381c1861b3f7ca1f3d63cf244b5 =
[
    [ "api_client.py", "api__client_8py.html", "api__client_8py" ],
    [ "commit_analyzer.py", "commit__analyzer_8py.html", "commit__analyzer_8py" ],
    [ "file_analyzer.py", "file__analyzer_8py.html", "file__analyzer_8py" ],
    [ "folder_analyzer.py", "folder__analyzer_8py.html", "folder__analyzer_8py" ],
    [ "git_analyzer.py", "git__analyzer_8py.html", "git__analyzer_8py" ],
    [ "main.py", "main_8py.html", "main_8py" ],
    [ "utils.py", "utils_8py.html", "utils_8py" ]
];